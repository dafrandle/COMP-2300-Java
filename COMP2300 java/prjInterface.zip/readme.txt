I included 2 extra files with the project.
1.Brainstorming.pdf
2.Interface.ncp

Brainstorming.pdf is notes I made before I wrote the code. 
I used it to help me plan how I was going to write said code.
I wrote these notes on my phone which why they are almost impossible to read.

Interface.ncp is the project file for the program I used to make the uml digram.
The program is called NClass and its way easier to use than plantUML.
You can find it here: http://nclass.sourceforge.net/
